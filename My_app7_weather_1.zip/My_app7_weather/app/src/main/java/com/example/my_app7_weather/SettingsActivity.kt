package com.example.my_app7_weather

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.ListPreference
import androidx.preference.PreferenceFragmentCompat
import com.example.my_app7_weather.utils.SettingsManager

class SettingsActivity : AppCompatActivity() {

    companion object {
        const val REQUEST_CODE_SETTINGS = 1001
        const val RESULT_SETTINGS_CHANGED = 1002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.settings_activity)

        supportFragmentManager
            .beginTransaction()
            .replace(R.id.settings, SettingsFragment())
            .commit()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Настройки"
    }

    override fun onSupportNavigateUp(): Boolean {
        // Устанавливаем результат, что настройки изменились
        setResult(RESULT_SETTINGS_CHANGED)
        onBackPressed()
        return true
    }

    override fun onBackPressed() {
        // Устанавливаем результат, что настройки изменились
        setResult(RESULT_SETTINGS_CHANGED)
        super.onBackPressed()
    }

    // Внутренний класс для фрагмента настроек
    class SettingsFragment : PreferenceFragmentCompat() {

        private lateinit var settingsManager: SettingsManager

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            // Загружаем настройки из XML файла
            setPreferencesFromResource(R.xml.root_preferences, rootKey)

            // Инициализируем SettingsManager через Singleton
            settingsManager = SettingsManager.getInstance(requireContext())
            setupPreferences()
        }

        private fun setupPreferences() {
            setupTemperatureUnitPreference()
            setupWindSpeedUnitPreference()
            setupPressureUnitPreference()
            setupLanguagePreference()
            setupUpdateIntervalPreference()
            setupGpsAccuracyPreference()
            setupGpsTimeoutPreference()
        }

        private fun setupTemperatureUnitPreference() {
            val preference = findPreference<ListPreference>("temperature_unit")
            preference?.setOnPreferenceChangeListener { _, newValue ->
                settingsManager.setTemperatureUnit(newValue.toString())
                updateTemperatureSummary(preference, newValue.toString())
                // Сообщаем об изменении настроек
                notifySettingsChanged()
                true
            }
            // Устанавливаем начальное описание
            preference?.let { updateTemperatureSummary(it, it.value ?: "celsius") }
        }

        private fun updateTemperatureSummary(preference: ListPreference, value: String) {
            val unitText = when (value) {
                "celsius" -> "Цельсий (°C)"
                "fahrenheit" -> "Фаренгейт (°F)"
                else -> "Цельсий (°C)"
            }
            preference.summary = "Текущие единицы: $unitText"
        }

        private fun setupWindSpeedUnitPreference() {
            val preference = findPreference<ListPreference>("wind_speed_unit")
            preference?.setOnPreferenceChangeListener { _, newValue ->
                settingsManager.setWindSpeedUnit(newValue.toString())
                updateWindSpeedSummary(preference, newValue.toString())
                // Сообщаем об изменении настроек
                notifySettingsChanged()
                true
            }
            preference?.let { updateWindSpeedSummary(it, it.value ?: "m_s") }
        }

        private fun updateWindSpeedSummary(preference: ListPreference, value: String) {
            val unitText = when (value) {
                "m_s" -> "м/с"
                "km_h" -> "км/ч"
                "mph" -> "миль/ч"
                else -> "м/с"
            }
            preference.summary = "Текущие единицы: $unitText"
        }

        private fun setupPressureUnitPreference() {
            val preference = findPreference<ListPreference>("pressure_unit")
            preference?.setOnPreferenceChangeListener { _, newValue ->
                settingsManager.setPressureUnit(newValue.toString())
                updatePressureSummary(preference, newValue.toString())
                // Сообщаем об изменении настроек
                notifySettingsChanged()
                true
            }
            preference?.let { updatePressureSummary(it, it.value ?: "hpa") }
        }

        private fun updatePressureSummary(preference: ListPreference, value: String) {
            val unitText = when (value) {
                "hpa" -> "гПа (hPa)"
                "mmhg" -> "мм рт.ст. (mmHg)"
                "inhg" -> "дюймы (inHg)"
                else -> "гПа (hPa)"
            }
            preference.summary = "Текущие единицы: $unitText"
        }

        private fun setupLanguagePreference() {
            val preference = findPreference<ListPreference>("language")
            preference?.setOnPreferenceChangeListener { _, newValue ->
                settingsManager.setLanguage(newValue.toString())
                updateLanguageSummary(preference, newValue.toString())
                // Сообщаем об изменении настроек
                notifySettingsChanged()
                // Показываем сообщение о необходимости перезагрузки
                showLanguageChangeMessage()
                true
            }
            preference?.let { updateLanguageSummary(it, it.value ?: "ru") }
        }

        private fun updateLanguageSummary(preference: ListPreference, value: String) {
            val langText = when (value) {
                "ru" -> "Русский"
                "en" -> "English"
                else -> "Русский"
            }
            preference.summary = "Текущий язык: $langText"
        }

        private fun showLanguageChangeMessage() {
            android.app.AlertDialog.Builder(requireContext())
                .setTitle("Изменение языка")
                .setMessage("Для полного применения изменений языка может потребоваться перезагрузка приложения.")
                .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                .show()
        }

        private fun setupUpdateIntervalPreference() {
            val preference = findPreference<ListPreference>("update_interval")
            preference?.setOnPreferenceChangeListener { _, newValue ->
                settingsManager.setUpdateInterval(newValue.toString().toInt())
                updateIntervalSummary(preference, newValue.toString().toInt())
                // Сообщаем об изменении настроек
                notifySettingsChanged()
                true
            }
            preference?.let { updateIntervalSummary(it, it.value?.toIntOrNull() ?: 30) }
        }

        private fun updateIntervalSummary(preference: ListPreference, value: Int) {
            val intervalText = when (value) {
                0 -> "Не обновлять автоматически"
                15 -> "15 минут"
                30 -> "30 минут"
                60 -> "1 час"
                120 -> "2 часа"
                else -> "$value минут"
            }
            preference.summary = "Интервал: $intervalText"
        }

        private fun setupGpsAccuracyPreference() {
            val preference = findPreference<ListPreference>("gps_accuracy")
            preference?.setOnPreferenceChangeListener { _, newValue ->
                settingsManager.setGpsAccuracy(newValue.toString())
                updateGpsAccuracySummary(preference, newValue.toString())
                // Сообщаем об изменении настроек
                notifySettingsChanged()
                true
            }
            preference?.let { updateGpsAccuracySummary(it, it.value ?: "high") }
        }

        private fun updateGpsAccuracySummary(preference: ListPreference, value: String) {
            val accuracyText = when (value) {
                "high" -> "Высокая (GPS)"
                "medium" -> "Средняя (Сеть)"
                "low" -> "Экономная"
                else -> "Высокая (GPS)"
            }
            preference.summary = "Текущая точность: $accuracyText"
        }

        private fun setupGpsTimeoutPreference() {
            val preference = findPreference<ListPreference>("gps_timeout")
            preference?.setOnPreferenceChangeListener { _, newValue ->
                settingsManager.setGpsTimeout(newValue.toString().toInt())
                updateGpsTimeoutSummary(preference, newValue.toString().toInt())
                // Сообщаем об изменении настроек
                notifySettingsChanged()
                true
            }
            preference?.let { updateGpsTimeoutSummary(it, it.value?.toIntOrNull() ?: 30) }
        }

        private fun updateGpsTimeoutSummary(preference: ListPreference, value: Int) {
            preference.summary = "Текущий таймаут: $value секунд"
        }

        private fun notifySettingsChanged() {
            // Устанавливаем результат, что настройки изменились
            activity?.setResult(RESULT_SETTINGS_CHANGED)
        }
    }
}