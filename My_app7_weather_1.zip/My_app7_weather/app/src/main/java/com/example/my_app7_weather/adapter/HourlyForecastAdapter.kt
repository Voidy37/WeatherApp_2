package com.example.my_app7_weather.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.my_app7_weather.R
import com.example.my_app7_weather.models.ForecastItem
import com.example.my_app7_weather.utils.SettingsManager
import java.text.SimpleDateFormat
import java.util.*

class HourlyForecastAdapter(
    private val context: Context,
    var items: List<ForecastItem>
) : RecyclerView.Adapter<HourlyForecastAdapter.ViewHolder>() {

    private val settingsManager = SettingsManager.getInstance(context)

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val time: TextView = view.findViewById(R.id.time)
        val icon: ImageView = view.findViewById(R.id.icon)
        val temperature: TextView = view.findViewById(R.id.temperature)
        val precipitation: TextView = view.findViewById(R.id.precipitation)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_hourly_forecast, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val tempSymbol = settingsManager.getTemperatureSymbol()

        // ИСПРАВЛЕНО: Используем температуру напрямую - API уже конвертировал ее
        holder.time.text = formatTime(item.dt)
        holder.temperature.text = "${item.main.temp.toInt()}$tempSymbol"
        holder.precipitation.text = "${(item.pop * 100).toInt()}%"

        val iconUrl = "https://openweathermap.org/img/wn/${item.weather.first().icon}.png"
        holder.icon.load(iconUrl)
    }

    override fun getItemCount() = items.size

    private fun formatTime(timestamp: Long): String {
        val date = Date(timestamp * 1000)
        val format = SimpleDateFormat("HH:mm", Locale.getDefault())
        return format.format(date)
    }

}