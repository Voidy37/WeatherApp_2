package com.example.my_app7_weather.repository

import android.content.Context
import android.util.Log
import com.example.my_app7_weather.api.WeatherApiService
import com.example.my_app7_weather.models.WeatherResponse
import com.example.my_app7_weather.models.ForecastResponse
import com.example.my_app7_weather.utils.SettingsManager

class WeatherRepository(private val context: Context) {
    private val apiService = WeatherApiService.WeatherApi.retrofitService
    private val settingsManager = SettingsManager.getInstance(context)

    suspend fun getCurrentWeather(lat: Double, lon: Double): Result<WeatherResponse> {
        return try {
            Log.d("WeatherRepository", "🔄 REAL API CALL: lat=$lat, lon=$lon")
            val units = settingsManager.getApiUnits()
            val lang = settingsManager.getApiLanguageCode()
            Log.d("WeatherRepository", "📊 Settings: units=$units, lang=$lang")

            val result = apiService.getCurrentWeather(lat, lon, units, lang)
            Log.d("WeatherRepository", "✅ REAL API RESPONSE: ${result.name}, temp=${result.main.temp}°")
            Result.success(result)
        } catch (e: Exception) {
            Log.e("WeatherRepository", "❌ REAL API ERROR: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun getWeatherByCity(cityName: String): Result<WeatherResponse> {
        return try {
            Log.d("WeatherRepository", "🔄 REAL CITY SEARCH: $cityName")
            val units = settingsManager.getApiUnits()
            val lang = settingsManager.getApiLanguageCode()

            val result = apiService.getWeatherByCity(cityName, units, lang)
            Log.d("WeatherRepository", "✅ REAL CITY FOUND: ${result.name}, temp=${result.main.temp}°")
            Result.success(result)
        } catch (e: Exception) {
            Log.e("WeatherRepository", "❌ CITY SEARCH ERROR: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun getForecast(lat: Double, lon: Double): Result<ForecastResponse> {
        return try {
            Log.d("WeatherRepository", "🔄 REAL FORECAST API: lat=$lat, lon=$lon")
            val units = settingsManager.getApiUnits()
            val lang = settingsManager.getApiLanguageCode()

            val result = apiService.getForecast(lat, lon, units, lang)
            Log.d("WeatherRepository", "✅ FORECAST DATA: ${result.list.size} items")
            Result.success(result)
        } catch (e: Exception) {
            Log.e("WeatherRepository", "❌ FORECAST API ERROR: ${e.message}")
            Result.failure(e)
        }
    }
}