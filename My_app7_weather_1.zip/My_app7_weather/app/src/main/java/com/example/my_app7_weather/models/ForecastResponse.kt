package com.example.my_app7_weather.models

data class ForecastResponse(
    val list: List<ForecastItem>,
    val city: City
)

data class ForecastItem(
    val dt: Long,
    val main: MainForecast,
    val weather: List<Weather>,
    val wind: Wind,
    val visibility: Int,
    val pop: Double, // Probability of precipitation
    val dt_txt: String
)

data class MainForecast(
    val temp: Double,
    val feels_like: Double,
    val temp_min: Double,
    val temp_max: Double,
    val pressure: Int,
    val humidity: Int
)