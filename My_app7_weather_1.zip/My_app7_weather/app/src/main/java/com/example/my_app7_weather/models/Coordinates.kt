package com.example.my_app7_weather.models

data class Coordinates(
    val lon: Double,
    val lat: Double
)