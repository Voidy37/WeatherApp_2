package com.example.my_app7_weather.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.my_app7_weather.R
import android.widget.ImageButton
import com.example.my_app7_weather.utils.SettingsManager

class QuickSwitchAdapter(
    private val context: Context,
    private var items: List<Pair<String, Double>>, // Pair<Город, Температура> (уже конвертирована API)
    private val onItemClick: (String) -> Unit,
    private val onDeleteClick: (String) -> Unit
) : RecyclerView.Adapter<QuickSwitchAdapter.CityViewHolder>() {

    private val settingsManager = SettingsManager.getInstance(context)

    class CityViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cityName: TextView = view.findViewById(R.id.cityName)
        val temperature: TextView = view.findViewById(R.id.temperature)
        val deleteButton: ImageButton = view.findViewById(R.id.deleteButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CityViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_quick_switch_city, parent, false)
        return CityViewHolder(view)
    }

    override fun onBindViewHolder(holder: CityViewHolder, position: Int) {
        val (city, temperature) = items[position]
        holder.cityName.text = city

        // ИСПРАВЛЕНО: НЕ конвертируем температуру - она уже конвертирована API
        val tempSymbol = settingsManager.getTemperatureSymbol()
        holder.temperature.text = "${temperature.toInt()}$tempSymbol"

        holder.itemView.setOnClickListener { onItemClick(city) }
        holder.deleteButton.setOnClickListener { onDeleteClick(city) }
    }

    override fun getItemCount() = items.size

    fun updateData(newItems: List<Pair<String, Double>>) {
        items = newItems
        notifyDataSetChanged()
    }

    // УДАЛЕНО: метод convertTemperature() - больше не нужен
}