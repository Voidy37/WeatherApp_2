package com.example.my_app7_weather.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.util.Log
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import java.util.concurrent.TimeUnit

class LocationHelper(
    private val context: Context,
    private val locationClient: FusedLocationProviderClient
) {
    private val settingsManager = SettingsManager.getInstance(context)

    fun getCurrentLocation(callback: (Location?) -> Unit) {
        Log.d("LocationHelper", "=== НАЧАЛО ПОЛУЧЕНИЯ ЛОКАЦИИ ===")

        if (!hasLocationPermission()) {
            Log.e("LocationHelper", "❌ НЕТ РАЗРЕШЕНИЙ на геолокацию")
            callback(null)
            return
        }

        Log.d("LocationHelper", "✅ Разрешения есть, запрашиваем локацию...")

        try {
            // Простой запрос последней известной локации
            locationClient.lastLocation
                .addOnSuccessListener { location ->
                    if (location != null) {
                        Log.d("LocationHelper", "✅ Локация получена: lat=${location.latitude}, lon=${location.longitude}")
                        Log.d("LocationHelper", "📊 Настройки GPS: accuracy=${settingsManager.getGpsAccuracy()}, timeout=${settingsManager.getGpsTimeout()}сек")
                    } else {
                        Log.e("LocationHelper", "❌ Локация = null (возможно GPS выключен)")
                    }
                    callback(location)
                }
                .addOnFailureListener { exception ->
                    Log.e("LocationHelper", "❌ Ошибка получения локации: ${exception.message}")
                    exception.printStackTrace()
                    callback(null)
                }
        } catch (securityException: SecurityException) {
            Log.e("LocationHelper", "❌ SecurityException: Разрешение отозвано во время запроса")
            securityException.printStackTrace()
            callback(null)
        }
    }

    private fun hasLocationPermission(): Boolean {
        val fineLocationGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarseLocationGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        Log.d("LocationHelper", "Проверка разрешений: FINE=$fineLocationGranted, COARSE=$coarseLocationGranted")

        return fineLocationGranted || coarseLocationGranted
    }
}