package com.example.my_app7_weather.utils

import com.example.my_app7_weather.models.ForecastItem
import java.text.SimpleDateFormat
import java.util.*

object ForecastHelper {

    /**
     * Создает почасовой прогноз на 24 часа начиная с 00:00 СЕГОДНЯШНЕГО дня
     */
    fun create24HourForecastFromMidnight(forecastItems: List<ForecastItem>): List<ForecastItem> {
        if (forecastItems.isEmpty()) return emptyList()

        val hourlyData = mutableListOf<ForecastItem>()

        // Начинаем с 00:00 СЕГОДНЯ
        val midnight = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // Создаем 24 часа начиная с полуночи
        for (hour in 0 until 24) {
            val targetTime = Calendar.getInstance().apply {
                timeInMillis = midnight.timeInMillis
                add(Calendar.HOUR_OF_DAY, hour)
            }

            // Находим ближайший интервал для этого часа
            val sourceItem = findClosestInterval(forecastItems, targetTime.timeInMillis)

            // Создаем почасовой элемент на основе найденного интервала
            val hourlyItem = sourceItem.copy(
                dt = targetTime.timeInMillis / 1000
            )
            hourlyData.add(hourlyItem)
        }

        return hourlyData
    }

    /**
     * Создает почасовой прогноз на 24 часа начиная с ТЕКУЩЕГО времени
     */
    fun create24HourForecastFromNow(forecastItems: List<ForecastItem>): List<ForecastItem> {
        if (forecastItems.isEmpty()) return emptyList()

        val hourlyData = mutableListOf<ForecastItem>()

        // Начинаем с текущего часа
        val now = Calendar.getInstance().apply {
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        for (hour in 0 until 24) {
            val targetTime = Calendar.getInstance().apply {
                timeInMillis = now.timeInMillis
                add(Calendar.HOUR_OF_DAY, hour)
            }

            val sourceItem = findClosestInterval(forecastItems, targetTime.timeInMillis)
            val hourlyItem = sourceItem.copy(dt = targetTime.timeInMillis / 1000)
            hourlyData.add(hourlyItem)
        }

        return hourlyData
    }

    /**
     * Создает почасовой прогноз на 48 часов для большей информации
     */
    fun create48HourForecastFromMidnight(forecastItems: List<ForecastItem>): List<ForecastItem> {
        if (forecastItems.isEmpty()) return emptyList()

        val hourlyData = mutableListOf<ForecastItem>()

        val midnight = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // 48 часов вместо 24
        for (hour in 0 until 48) {
            val targetTime = Calendar.getInstance().apply {
                timeInMillis = midnight.timeInMillis
                add(Calendar.HOUR_OF_DAY, hour)
            }

            val sourceItem = findClosestInterval(forecastItems, targetTime.timeInMillis)
            val hourlyItem = sourceItem.copy(dt = targetTime.timeInMillis / 1000)
            hourlyData.add(hourlyItem)
        }

        return hourlyData
    }

    /**
     * Находит ближайший прогнозный интервал к заданному времени
     */
    private fun findClosestInterval(forecastItems: List<ForecastItem>, targetTime: Long): ForecastItem {
        return forecastItems.minByOrNull { item ->
            Math.abs(item.dt * 1000 - targetTime)
        } ?: forecastItems.first()
    }

    /**
     * Проверяет корректность созданного прогноза (для отладки)
     */
    fun debugForecast(hourlyItems: List<ForecastItem>) {
        println("=== ДЕБАГ ПОЧАСОВОГО ПРОГНОЗА ===")
        hourlyItems.forEachIndexed { index, item ->
            val date = Date(item.dt * 1000)
            val timeFormat = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
            println("${index + 1}. ${timeFormat.format(date)} - ${item.main.temp}°C")
        }
        println("Всего элементов: ${hourlyItems.size}")
    }
}