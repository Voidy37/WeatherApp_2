package com.example.my_app7_weather.utils

import android.content.Context
import android.content.SharedPreferences

public class SettingsManager private constructor(context: Context) {
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("weather_app_settings", Context.MODE_PRIVATE)

    public companion object {
        // Единицы измерения
        private const val KEY_TEMPERATURE_UNIT = "temperature_unit"
        private const val KEY_WIND_SPEED_UNIT = "wind_speed_unit"
        private const val KEY_PRESSURE_UNIT = "pressure_unit"

        // Язык
        private const val KEY_LANGUAGE = "language"

        // Обновление
        private const val KEY_UPDATE_INTERVAL = "update_interval"

        // GPS
        private const val KEY_GPS_ACCURACY = "gps_accuracy"
        private const val KEY_GPS_TIMEOUT = "gps_timeout"

        // Значения по умолчанию
        private const val DEFAULT_TEMPERATURE_UNIT = "celsius"
        private const val DEFAULT_WIND_SPEED_UNIT = "m_s"
        private const val DEFAULT_PRESSURE_UNIT = "hpa"
        private const val DEFAULT_LANGUAGE = "ru"
        private const val DEFAULT_UPDATE_INTERVAL = 30
        private const val DEFAULT_GPS_ACCURACY = "high"
        private const val DEFAULT_GPS_TIMEOUT = 30

        @Volatile
        private var INSTANCE: SettingsManager? = null

        public fun getInstance(context: Context): SettingsManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SettingsManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    // === ЕДИНИЦЫ ИЗМЕРЕНИЯ ===

    public fun getTemperatureUnit(): String {
        return sharedPreferences.getString(KEY_TEMPERATURE_UNIT, DEFAULT_TEMPERATURE_UNIT) ?: DEFAULT_TEMPERATURE_UNIT
    }

    public fun setTemperatureUnit(unit: String) {
        sharedPreferences.edit().putString(KEY_TEMPERATURE_UNIT, unit).apply()
    }

    public fun getWindSpeedUnit(): String {
        return sharedPreferences.getString(KEY_WIND_SPEED_UNIT, DEFAULT_WIND_SPEED_UNIT) ?: DEFAULT_WIND_SPEED_UNIT
    }

    public fun setWindSpeedUnit(unit: String) {
        sharedPreferences.edit().putString(KEY_WIND_SPEED_UNIT, unit).apply()
    }

    public fun getPressureUnit(): String {
        return sharedPreferences.getString(KEY_PRESSURE_UNIT, DEFAULT_PRESSURE_UNIT) ?: DEFAULT_PRESSURE_UNIT
    }

    public fun setPressureUnit(unit: String) {
        sharedPreferences.edit().putString(KEY_PRESSURE_UNIT, unit).apply()
    }

    // === ЯЗЫК ===

    public fun getLanguage(): String {
        return sharedPreferences.getString(KEY_LANGUAGE, DEFAULT_LANGUAGE) ?: DEFAULT_LANGUAGE
    }

    public fun setLanguage(language: String) {
        sharedPreferences.edit().putString(KEY_LANGUAGE, language).apply()
    }

    // === ОБНОВЛЕНИЕ ===

    public fun getUpdateInterval(): Int {
        return sharedPreferences.getInt(KEY_UPDATE_INTERVAL, DEFAULT_UPDATE_INTERVAL)
    }

    public fun setUpdateInterval(minutes: Int) {
        sharedPreferences.edit().putInt(KEY_UPDATE_INTERVAL, minutes).apply()
    }

    // === GPS ===

    public fun getGpsAccuracy(): String {
        return sharedPreferences.getString(KEY_GPS_ACCURACY, DEFAULT_GPS_ACCURACY) ?: DEFAULT_GPS_ACCURACY
    }

    public fun setGpsAccuracy(accuracy: String) {
        sharedPreferences.edit().putString(KEY_GPS_ACCURACY, accuracy).apply()
    }

    public fun getGpsTimeout(): Int {
        return sharedPreferences.getInt(KEY_GPS_TIMEOUT, DEFAULT_GPS_TIMEOUT)
    }

    public fun setGpsTimeout(seconds: Int) {
        sharedPreferences.edit().putInt(KEY_GPS_TIMEOUT, seconds).apply()
    }

    // === УТИЛИТЫ ДЛЯ API ===

    public fun getApiLanguageCode(): String {
        return when (getLanguage()) {
            "ru" -> "ru"
            "en" -> "en"
            else -> "ru"
        }
    }

    public fun getApiUnits(): String {
        return when (getTemperatureUnit()) {
            "celsius" -> "metric"
            "fahrenheit" -> "imperial"
            else -> "metric"
        }
    }

    // === УТИЛИТЫ ДЛЯ ОТОБРАЖЕНИЯ ===

    public fun getTemperatureSymbol(): String {
        return when (getTemperatureUnit()) {
            "celsius" -> "°C"
            "fahrenheit" -> "°F"
            else -> "°C"
        }
    }

    public fun getWindSpeedSymbol(): String {
        return when (getWindSpeedUnit()) {
            "m_s" -> " м/с"
            "km_h" -> " км/ч"
            "mph" -> " миль/ч"
            else -> " м/с"
        }
    }

    public fun getPressureSymbol(): String {
        return when (getPressureUnit()) {
            "hpa" -> " гПа"
            "mmhg" -> " мм рт.ст."
            "inhg" -> " дюймы"
            else -> " гПа"
        }
    }
}