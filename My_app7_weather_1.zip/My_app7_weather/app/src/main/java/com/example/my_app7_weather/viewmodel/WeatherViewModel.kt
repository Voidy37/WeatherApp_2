package com.example.my_app7_weather.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.my_app7_weather.models.WeatherResponse
import com.example.my_app7_weather.models.ForecastResponse
import com.example.my_app7_weather.repository.WeatherRepository
import kotlinx.coroutines.launch

class WeatherViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = WeatherRepository(application.applicationContext)

    private val _currentWeather = MutableLiveData<WeatherResponse>()
    val currentWeather: LiveData<WeatherResponse> = _currentWeather

    private val _forecast = MutableLiveData<ForecastResponse>()
    val forecast: LiveData<ForecastResponse> = _forecast

    private val _loading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = _loading

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    fun loadWeather(lat: Double, lon: Double) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null

            // Загружаем текущую погоду и прогноз параллельно
            val weatherResult = repository.getCurrentWeather(lat, lon)
            val forecastResult = repository.getForecast(lat, lon)

            weatherResult.onSuccess { _currentWeather.value = it }
                .onFailure { _error.value = "Ошибка загрузки погоды: ${it.message}" }

            forecastResult.onSuccess { _forecast.value = it }
                .onFailure { _error.value = "Ошибка загрузки прогноза: ${it.message}" }

            _loading.value = false
        }
    }

    fun searchWeather(cityName: String) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null

            repository.getWeatherByCity(cityName).onSuccess { weather ->
                _currentWeather.value = weather
                // Загружаем прогноз по координатам найденного города
                loadWeather(weather.coord.lat, weather.coord.lon)
            }.onFailure {
                _error.value = "Город не найден"
                _loading.value = false
            }
        }
    }
}