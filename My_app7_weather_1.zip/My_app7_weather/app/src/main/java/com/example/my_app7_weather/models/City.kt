package com.example.my_app7_weather.models

data class City(
    val name: String,
    val country: String
)