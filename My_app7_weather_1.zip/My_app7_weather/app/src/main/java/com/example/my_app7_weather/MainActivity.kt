package com.example.my_app7_weather

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import coil.load
import com.example.my_app7_weather.adapter.DailyForecastAdapter
import com.example.my_app7_weather.adapter.HourlyForecastAdapter
import com.example.my_app7_weather.adapter.QuickSwitchAdapter
import com.example.my_app7_weather.adapter.SearchHistoryAdapter
import com.example.my_app7_weather.databinding.ActivityMainBinding
import com.example.my_app7_weather.models.ForecastItem
import com.example.my_app7_weather.models.ForecastResponse
import com.example.my_app7_weather.models.WeatherResponse
import com.example.my_app7_weather.utils.ForecastHelper
import com.example.my_app7_weather.utils.LocationHelper
import com.example.my_app7_weather.utils.PreferencesHelper
import com.example.my_app7_weather.utils.SettingsManager
import com.example.my_app7_weather.viewmodel.WeatherViewModel
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: WeatherViewModel by viewModels()
    private lateinit var locationClient: FusedLocationProviderClient
    private lateinit var locationHelper: LocationHelper
    private lateinit var hourlyAdapter: HourlyForecastAdapter
    private lateinit var dailyAdapter: DailyForecastAdapter
    private lateinit var preferencesHelper: PreferencesHelper
    private lateinit var settingsManager: SettingsManager
    private lateinit var historyAdapter: SearchHistoryAdapter
    private lateinit var quickSwitchAdapter: QuickSwitchAdapter

    // Добавлено: Константа для запроса настроек
    companion object {
        private const val REQUEST_CODE_SETTINGS = 1001
    }

    private val locationPermissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        when {
            permissions.getOrDefault(Manifest.permission.ACCESS_FINE_LOCATION, false) -> {
                getCurrentLocationWeather()
            }
            permissions.getOrDefault(Manifest.permission.ACCESS_COARSE_LOCATION, false) -> {
                getCurrentLocationWeather()
            }
            else -> {
                Snackbar.make(binding.root, "Разрешение на локацию отклонено", Snackbar.LENGTH_LONG).show()
                loadMoscowWeather()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerViews()
        setupViewModel()
        setupLocation()
        setupPreferences()
        setupSettings()
        setupListeners()
        updateQuickSwitchWidget()

        if (hasLocationPermission()) {
            getCurrentLocationWeather()
        } else {
            requestLocationPermission()
        }
    }

    // ДОБАВЛЕНО: Обработка результата из SettingsActivity
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_SETTINGS && resultCode == SettingsActivity.RESULT_SETTINGS_CHANGED) {
            // Настройки изменились - обновляем UI
            Log.d("MainActivity", "Настройки изменились, обновляем UI")
            refreshWeatherData()
        }
    }

    // ДОБАВЛЕНО: Метод для обновления данных при изменении настроек
    private fun refreshWeatherData() {
        // Обновляем текущие данные
        viewModel.currentWeather.value?.let { weather ->
            updateWeatherUI(weather)
        }

        // Обновляем прогноз
        viewModel.forecast.value?.let { forecast ->
            updateForecastUI(forecast)
        }

        // Обновляем избранные города
        updateQuickSwitchWidget()

        // Перезагружаем данные с сервера с новыми настройками
        viewModel.currentWeather.value?.let { weather ->
            Log.d("MainActivity", "Перезагружаем данные с новыми настройками")
            viewModel.loadWeather(weather.coord.lat, weather.coord.lon)
        }
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
    }

    private fun setupRecyclerViews() {
        binding.quickSwitchList.apply {
            layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
            quickSwitchAdapter = QuickSwitchAdapter(
                context = this@MainActivity, // ДОБАВЛЕНО: передаем context
                items = emptyList(),
                onItemClick = { city -> performSearch(city) },
                onDeleteClick = { city ->
                    preferencesHelper.removeFavoriteCity(city)
                    updateQuickSwitchWidget()
                    Snackbar.make(binding.root, "$city удален из избранного", Snackbar.LENGTH_SHORT).show()

                    val currentCity = binding.cityName.text.toString().split(",")[0].trim()
                    if (currentCity == city) {
                        updateFavoriteButton(currentCity)
                    }
                }
            )
            adapter = quickSwitchAdapter
        }

        binding.hourlyForecastList.apply {
            layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
            hourlyAdapter = HourlyForecastAdapter(this@MainActivity, emptyList())
            adapter = hourlyAdapter
        }

        binding.dailyForecastList.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            dailyAdapter = DailyForecastAdapter(this@MainActivity, emptyList())
            adapter = dailyAdapter
        }
    }

    private fun setupViewModel() {
        viewModel.currentWeather.observe(this) { weather ->
            weather?.let { updateWeatherUI(it) }
        }

        viewModel.forecast.observe(this) { forecast ->
            forecast?.let { updateForecastUI(it) }
        }

        viewModel.loading.observe(this) { isLoading ->
            binding.loading.visibility = if (isLoading == true) View.VISIBLE else View.GONE
            binding.fabLocation.isEnabled = isLoading != true
        }

        viewModel.error.observe(this) { error ->
            error?.let {
                Snackbar.make(binding.root, error, Snackbar.LENGTH_LONG).show()
            }
        }
    }

    private fun setupLocation() {
        locationClient = LocationServices.getFusedLocationProviderClient(this)
        locationHelper = LocationHelper(this, locationClient)
    }

    private fun setupPreferences() {
        preferencesHelper = PreferencesHelper(this)
    }

    private fun setupSettings() {
        settingsManager = SettingsManager.getInstance(this)
    }

    private fun setupListeners() {
        binding.fabLocation.setOnClickListener {
            getCurrentLocationWeather()
        }

        binding.cityName.setOnLongClickListener {
            showSearchDialog()
            true
        }

        binding.favoriteButton.setOnClickListener {
            val fullCityText = binding.cityName.text.toString()
            val currentCity = fullCityText.split(",")[0].trim()

            // Проверяем, что город валидный и не является placeholder'ом
            val invalidCities = listOf("Город", "Загрузка...", "Загрузка", "--")
            val isValidCity = currentCity.isNotEmpty() &&
                    !invalidCities.contains(currentCity) &&
                    !currentCity.contains("Загрузка") &&
                    currentCity.length > 2

            if (isValidCity) {
                toggleFavoriteCity(currentCity)
            } else {
                Snackbar.make(binding.root, "Сначала выберите или найдите город", Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadMoscowWeather() {
        Log.d("MainActivity", "Загружаем погоду в Москве")
        viewModel.loadWeather(55.7558, 37.6173)
    }

    private fun updateWeatherUI(weather: WeatherResponse) {
        Log.d("MainActivity", "Обновление UI: ${weather.name}, temp=${weather.main.temp}° (already converted by API)")

        // Скрываем сообщение о загрузке
        binding.emptyState.visibility = View.GONE

        val cityDisplayName = "${weather.name}, ${weather.sys.country}"
        binding.cityName.text = cityDisplayName

        // ИСПРАВЛЕНО: НЕ конвертируем температуру - API уже сделал это
        val tempSymbol = settingsManager.getTemperatureSymbol()
        binding.temperature.text = "${weather.main.temp.toInt()}$tempSymbol"

        binding.weatherDescription.text = weather.weather.first().description.capitalizeWords()

        // ИСПРАВЛЕНО: feels_like тоже НЕ конвертируем
        binding.feelsLike.text = "${weather.main.feels_like.toInt()}$tempSymbol"

        binding.humidity.text = "${weather.main.humidity}%"

        updateFavoriteButton(weather.name)

        // ИСПРАВЛЕНО: Сохраняем температуру как есть (уже конвертированную)
        preferencesHelper.updateCityTemperature(weather.name, weather.main.temp.toString())
        updateQuickSwitchWidget()

        // Используем настройки для единиц измерения
        val windSymbol = settingsManager.getWindSpeedSymbol()
        val pressureSymbol = settingsManager.getPressureSymbol()

        // Конвертируем давление
        val pressureValue = convertPressure(weather.main.pressure.toDouble())
        binding.pressure.text = "${pressureValue.toInt()}$pressureSymbol"

        binding.windSpeed.text = "${String.format(Locale.getDefault(), "%.1f", weather.wind.speed)}$windSymbol"
        binding.visibility.text = "${weather.visibility / 1000} км"

        // ИСПРАВЛЕНО: min/max температуру НЕ конвертируем
        binding.tempMinMax.text = "${weather.main.temp_min.toInt()}$tempSymbol/${weather.main.temp_max.toInt()}$tempSymbol"

        binding.sunrise.text = convertTimestampToTime(weather.sys.sunrise)
        binding.sunset.text = convertTimestampToTime(weather.sys.sunset)

        val iconUrl = "https://openweathermap.org/img/wn/${weather.weather.first().icon}@2x.png"
        binding.weatherIcon.load(iconUrl) {
            crossfade(true)
            error(android.R.drawable.ic_menu_report_image)
        }
    }

    // ДОБАВЛЕНО: Конвертация давления
    private fun convertPressure(pressureHpa: Double): Double {
        return when (settingsManager.getPressureUnit()) {
            "hpa" -> pressureHpa
            "mmhg" -> pressureHpa * 0.750062
            "inhg" -> pressureHpa * 0.02953
            else -> pressureHpa
        }
    }

    private fun updateFavoriteButton(cityName: String) {
        val cleanCityName = cityName.split(",")[0].trim()
        val isFavorite = preferencesHelper.isFavorite(cleanCityName)

        if (isFavorite) {
            binding.favoriteButton.text = "★ В избранном"
            binding.favoriteButton.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_red_light))
        } else {
            binding.favoriteButton.text = "☆ В избранное"
            binding.favoriteButton.setBackgroundColor(ContextCompat.getColor(this, android.R.color.darker_gray))
        }
    }

    private fun toggleFavoriteCity(cityName: String) {
        val cleanCityName = cityName.split(",")[0].trim()
        val isNowFavorite = preferencesHelper.toggleFavorite(cleanCityName)

        if (isNowFavorite) {
            Snackbar.make(binding.root, "$cleanCityName добавлен в избранное", Snackbar.LENGTH_SHORT).show()
        } else {
            Snackbar.make(binding.root, "$cleanCityName удален из избранного", Snackbar.LENGTH_SHORT).show()
        }
        updateFavoriteButton(cleanCityName)
        updateQuickSwitchWidget()
    }

    // ИЗМЕНЕНО: Обновление виджета быстрого переключения
    private fun updateQuickSwitchWidget() {
        val favoriteCities = preferencesHelper.getFavoriteCities()
        if (favoriteCities.isNotEmpty()) {
            binding.quickSwitchCard.visibility = View.VISIBLE
            val temperatures = preferencesHelper.getFavoriteTemperatures()
            val items = favoriteCities.map { city ->
                val tempString = temperatures[city] ?: "0"
                val tempKelvin = tempString.toDoubleOrNull() ?: 0.0

                // ИСПРАВЛЕНО: Создаем Pair<String, Double> (Город, Температура в Kelvin)
                // QuickSwitchAdapter сам будет конвертировать температуру
                Pair(city, tempKelvin)
            }
            quickSwitchAdapter.updateData(items)
        } else {
            binding.quickSwitchCard.visibility = View.GONE
        }
    }

    // ДОБАВЛЕНО: Конвертация температуры
    private fun convertTemperature(kelvin: Double): Double {
        return when (settingsManager.getTemperatureUnit()) {
            "celsius" -> kelvin - 273.15
            "fahrenheit" -> (kelvin - 273.15) * 9/5 + 32
            else -> kelvin - 273.15
        }
    }

    private fun updateForecastUI(forecast: ForecastResponse) {
        Log.d("MainActivity", "Обновление прогноза: ${forecast.list.size} элементов")

        // Обновляем адаптеры с новыми данными
        val hourlyItems = ForecastHelper.create24HourForecastFromMidnight(forecast.list)
        hourlyAdapter.items = hourlyItems
        hourlyAdapter.notifyDataSetChanged()

        val dailyItems = groupForecastByDay(forecast.list)
        dailyAdapter.items = dailyItems
        dailyAdapter.notifyDataSetChanged()

        Log.d("MainActivity", "Почасовой прогноз: ${hourlyItems.size} часов, Дневной прогноз: ${dailyItems.size} дней")
    }

    private fun groupForecastByDay(forecastItems: List<ForecastItem>): List<ForecastItem> {
        val dailyItems = mutableListOf<ForecastItem>()
        val processedDays = mutableSetOf<String>()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

        for (item in forecastItems) {
            val date = Date(item.dt * 1000)
            val dayKey = dateFormat.format(date)

            if (!processedDays.contains(dayKey)) {
                processedDays.add(dayKey)
                dailyItems.add(item)
            }
        }

        // ИСПРАВЛЕНО: Генерация 7-го дня если дней меньше 7
        if (dailyItems.size == 6) {
            val lastItem = dailyItems.last()
            val fakeItem = lastItem.copy(
                dt = lastItem.dt + 24 * 60 * 60, // +1 день
                main = lastItem.main.copy(
                    temp_min = lastItem.main.temp_min - 2.0,
                    temp_max = lastItem.main.temp_max - 1.0
                ),
                pop = lastItem.pop * 0.8 // Немного меньше осадков
            )
            dailyItems.add(fakeItem)
        }

        return dailyItems.take(7)
    }

    private fun convertTimestampToTime(timestamp: Long): String {
        val date = Date(timestamp * 1000)
        val format = SimpleDateFormat("HH:mm", Locale.getDefault())
        return format.format(date)
    }

    private fun String.capitalizeWords(): String {
        return this.split(" ").joinToString(" ") { word ->
            word.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
        }
    }

    private fun getCurrentLocationWeather() {
        if (!hasLocationPermission()) {
            requestLocationPermission()
            return
        }

        locationHelper.getCurrentLocation { location ->
            if (location != null) {
                viewModel.loadWeather(location.latitude, location.longitude)
            } else {
                Snackbar.make(binding.root, "Локация не найдена. Используем Москву", Snackbar.LENGTH_SHORT).show()
                loadMoscowWeather()
            }
        }
    }

    private fun hasLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestLocationPermission() {
        val permissions = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        locationPermissionRequest.launch(permissions)
    }

    private fun showSearchDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_search, null)
        val searchInput = dialogView.findViewById<TextInputEditText>(R.id.searchInput)
        val searchHistoryList = dialogView.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.searchHistoryList)
        val historyTitle = dialogView.findViewById<TextView>(R.id.historyTitle)
        val cancelButton = dialogView.findViewById<Button>(R.id.cancelButton)
        val searchButton = dialogView.findViewById<Button>(R.id.searchButton)

        dialogView.findViewById<Button>(R.id.favoriteButton)?.visibility = View.GONE

        historyAdapter = SearchHistoryAdapter(
            items = emptyList(),
            onItemClick = { city ->
                performSearch(city)
                currentSearchDialog?.dismiss()
            },
            onDeleteClick = { city ->
                preferencesHelper.removeFromSearchHistory(city)
                updateSearchHistory(historyAdapter, historyTitle, preferencesHelper.getSearchHistory())
            }
        )

        searchHistoryList.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = historyAdapter
        }

        val searchHistory = preferencesHelper.getSearchHistory()
        updateSearchHistory(historyAdapter, historyTitle, searchHistory)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Поиск города")
            .setView(dialogView)
            .setCancelable(true)
            .create()

        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val query = searchInput.text.toString().trim()
                if (query.isNotEmpty()) {
                    performSearch(query)
                    dialog.dismiss()
                } else {
                    searchInput.error = "Введите название города"
                }
                true
            } else false
        }

        searchButton.setOnClickListener {
            val query = searchInput.text.toString().trim()
            if (query.isNotEmpty()) {
                performSearch(query)
                dialog.dismiss()
            } else {
                searchInput.error = "Введите название города"
            }
        }

        cancelButton.setOnClickListener { dialog.dismiss() }

        dialog.setOnShowListener {
            searchInput.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }

        currentSearchDialog = dialog
        dialog.show()
    }

    private var currentSearchDialog: AlertDialog? = null

    private fun showAddToFavoritesDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_favorite, null)
        val cityInput = dialogView.findViewById<TextInputEditText>(R.id.cityInput)
        val cancelButton = dialogView.findViewById<Button>(R.id.cancelButton)
        val addButton = dialogView.findViewById<Button>(R.id.addButton)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Добавить город в избранное")
            .setView(dialogView)
            .setCancelable(true)
            .create()

        addButton.setOnClickListener {
            val cityName = cityInput.text.toString().trim()
            if (cityName.isNotEmpty()) {
                val success = preferencesHelper.addFavoriteCity(cityName)
                if (success) {
                    Snackbar.make(binding.root, "$cityName добавлен в избранное", Snackbar.LENGTH_SHORT).show()
                    dialog.dismiss()
                    updateQuickSwitchWidget()
                    val currentCity = binding.cityName.text.toString().split(",")[0].trim()
                    if (currentCity == cityName) updateFavoriteButton(currentCity)
                } else {
                    Snackbar.make(binding.root, "Не удалось добавить город. Лимит 10 городов.", Snackbar.LENGTH_LONG).show()
                }
            } else {
                cityInput.error = "Введите название города"
            }
        }

        cancelButton.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun updateSearchHistory(adapter: SearchHistoryAdapter, titleView: TextView, history: List<String>) {
        adapter.updateData(history)
        titleView.visibility = if (history.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun performSearch(cityName: String) {
        if (cityName.isNotEmpty()) {
            preferencesHelper.addToSearchHistory(cityName)
            viewModel.searchWeather(cityName)
            Snackbar.make(binding.root, "Ищем: $cityName", Snackbar.LENGTH_SHORT).show()
        }
    }

    override fun onCreateOptionsMenu(menu: android.view.Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: android.view.MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_search -> { showSearchDialog(); true }
            R.id.action_favorites -> { showAddToFavoritesDialog(); true }
            // ИЗМЕНЕНО: Используем startActivityForResult для настроек
            R.id.action_settings -> {
                val intent = Intent(this, SettingsActivity::class.java)
                startActivityForResult(intent, REQUEST_CODE_SETTINGS)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        currentSearchDialog?.dismiss()
    }
}