package com.example.my_app7_weather.api

import com.example.my_app7_weather.models.WeatherResponse
import com.example.my_app7_weather.models.ForecastResponse
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherApiService {
    @GET("weather")
    suspend fun getCurrentWeather(
        @Query("lat") lat: Double,
        @Query("lon") lon: Double,
        @Query("units") units: String,  // Убрали значение по умолчанию
        @Query("lang") lang: String,    // Убрали значение по умолчанию
        @Query("appid") appid: String = WeatherApi.API_KEY
    ): WeatherResponse

    @GET("forecast")
    suspend fun getForecast(
        @Query("lat") lat: Double,
        @Query("lon") lon: Double,
        @Query("units") units: String,  // Убрали значение по умолчанию
        @Query("lang") lang: String,    // Убрали значение по умолчанию
        @Query("appid") appid: String = WeatherApi.API_KEY
    ): ForecastResponse

    @GET("weather")
    suspend fun getWeatherByCity(
        @Query("q") cityName: String,
        @Query("units") units: String,  // Убрали значение по умолчанию
        @Query("lang") lang: String,    // Убрали значение по умолчанию
        @Query("appid") appid: String = WeatherApi.API_KEY
    ): WeatherResponse

    object WeatherApi {
        private const val BASE_URL = "https://api.openweathermap.org/data/2.5/"
        const val API_KEY = "665b9e552e69600bece6e9b2745b09c9"

        val retrofitService: WeatherApiService by lazy {
            Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(WeatherApiService::class.java)
        }
    }
}