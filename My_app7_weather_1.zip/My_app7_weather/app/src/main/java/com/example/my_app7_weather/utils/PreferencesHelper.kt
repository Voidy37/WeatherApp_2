package com.example.my_app7_weather.utils

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class PreferencesHelper(context: Context) {
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("weather_app_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        private const val SEARCH_HISTORY_KEY = "search_history"
        private const val FAVORITE_CITIES_KEY = "favorite_cities"
        private const val FAVORITE_TEMPERATURES_KEY = "favorite_temperatures"
        private const val MAX_SEARCH_HISTORY = 5
        private const val MAX_FAVORITES = 10
    }

    // ==================== ИСТОРИЯ ПОИСКА ====================

    fun saveSearchHistory(history: List<String>) {
        val json = gson.toJson(history)
        sharedPreferences.edit().putString(SEARCH_HISTORY_KEY, json).apply()
    }

    fun getSearchHistory(): List<String> {
        val json = sharedPreferences.getString(SEARCH_HISTORY_KEY, null)
        return if (json != null) {
            val type = object : TypeToken<List<String>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } else {
            emptyList()
        }
    }

    fun addToSearchHistory(city: String) {
        val currentHistory = getSearchHistory().toMutableList()
        currentHistory.remove(city)
        currentHistory.add(0, city)

        if (currentHistory.size > MAX_SEARCH_HISTORY) {
            currentHistory.removeAt(currentHistory.size - 1)
        }
        saveSearchHistory(currentHistory)
    }

    fun removeFromSearchHistory(city: String) {
        val currentHistory = getSearchHistory().toMutableList()
        currentHistory.remove(city)
        saveSearchHistory(currentHistory)
    }

    fun clearSearchHistory() {
        sharedPreferences.edit().remove(SEARCH_HISTORY_KEY).apply()
    }

    // ==================== ИЗБРАННЫЕ ГОРОДА ====================

    fun saveFavoriteCities(cities: List<String>) {
        val json = gson.toJson(cities)
        sharedPreferences.edit().putString(FAVORITE_CITIES_KEY, json).apply()
    }

    fun getFavoriteCities(): List<String> {
        val json = sharedPreferences.getString(FAVORITE_CITIES_KEY, null)
        return if (json != null) {
            val type = object : TypeToken<List<String>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } else {
            emptyList()
        }
    }

    fun addFavoriteCity(city: String): Boolean {
        val currentFavorites = getFavoriteCities().toMutableList()

        if (currentFavorites.size >= MAX_FAVORITES) {
            return false  // Достигнут лимит
        }
        if (currentFavorites.contains(city)) {
            return true  // Уже в избранном
        }

        currentFavorites.add(city)
        saveFavoriteCities(currentFavorites)
        return true
    }

    fun removeFavoriteCity(city: String) {
        val currentFavorites = getFavoriteCities().toMutableList()
        currentFavorites.remove(city)
        saveFavoriteCities(currentFavorites)
    }

    fun isFavorite(city: String): Boolean {
        return getFavoriteCities().contains(city)
    }

    fun toggleFavorite(city: String): Boolean {
        return if (isFavorite(city)) {
            removeFavoriteCity(city)
            false
        } else {
            addFavoriteCity(city)
            true
        }
    }

    fun getFavoriteCitiesCount(): Int {
        return getFavoriteCities().size
    }

    fun clearFavoriteCities() {
        sharedPreferences.edit().remove(FAVORITE_CITIES_KEY).apply()
    }

    // ==================== ТЕМПЕРАТУРЫ ИЗБРАННЫХ ГОРОДОВ ====================

    fun saveFavoriteTemperatures(temperatures: Map<String, String>) {
        val json = gson.toJson(temperatures)
        sharedPreferences.edit().putString(FAVORITE_TEMPERATURES_KEY, json).apply()
    }

    fun getFavoriteTemperatures(): Map<String, String> {
        val json = sharedPreferences.getString(FAVORITE_TEMPERATURES_KEY, null)
        return if (json != null) {
            val type = object : TypeToken<Map<String, String>>() {}.type
            gson.fromJson(json, type) ?: emptyMap()
        } else {
            emptyMap()
        }
    }

    fun updateCityTemperature(city: String, temperature: String) {
        val currentTemperatures = getFavoriteTemperatures().toMutableMap()
        currentTemperatures[city] = temperature
        saveFavoriteTemperatures(currentTemperatures)
    }

    fun getCityTemperature(city: String): String {
        return getFavoriteTemperatures()[city] ?: "–°C"
    }

    // ==================== ОБЩИЕ МЕТОДЫ ====================

    fun clearAllData() {
        sharedPreferences.edit().clear().apply()
    }
}