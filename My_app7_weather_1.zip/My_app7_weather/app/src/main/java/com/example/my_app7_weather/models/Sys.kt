package com.example.my_app7_weather.models

data class Sys(
    val country: String,
    val sunrise: Long,
    val sunset: Long
)