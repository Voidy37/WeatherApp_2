package com.example.my_app7_weather.models

data class Wind(
    val speed: Double,
    val deg: Int
)